package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import baseModule.TestBase;

public class ChooseFlight extends TestBase
{
	@FindBy(how=How.XPATH,using="/html/body/div[2]/table/tbody/tr[1]/td[1]/input")
	public
	WebElement btnChooseFlights;
	
	public void clickbtnchooseFlights()
	{
		btnChooseFlights.click();
	}
	
	// Initializing the Page Objects:
			public ChooseFlight() {
				PageFactory.initElements(driver, this);
			}
	
	

}
