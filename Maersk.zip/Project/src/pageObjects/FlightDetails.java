package pageObjects;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import baseModule.TestBase;
import commonHelpers.PropertiesFileReader;

public class FlightDetails extends TestBase {
	
	@FindBy(how=How.ID,using="inputName")
	WebElement Name;

	
	@FindBy(how=How.ID,using="address")
	WebElement address;
	
	@FindBy(how=How.ID,using="city")
	WebElement city;
	
	@FindBy(how=How.ID,using="state")
	WebElement state;
	
	@FindBy(how=How.ID,using="zipCode")
	WebElement zipcode;
	
	@FindBy(how=How.ID,using="creditCardNumber")
	WebElement creditCardNumber;
	
	@FindBy(how=How.ID,using="creditCardMonth")
	WebElement creditMonth;
	
	@FindBy(how=How.ID,using="creditCardYear")
	WebElement creditYear;
	
	@FindBy(how=How.ID,using="nameOnCard")
	WebElement nameOnCard;
	
	@FindBy(how=How.XPATH,using="//input[@value='Purchase Flight']")
	WebElement btnPurchaseFlight;
	
	public void enterUserDetails() throws IOException 
	{
		Name.sendKeys(PropertiesFileReader.getData("name"));
		address.sendKeys(PropertiesFileReader.getData("address"));
		city.sendKeys(PropertiesFileReader.getData("city"));
		state.sendKeys(PropertiesFileReader.getData("state"));
		zipcode.sendKeys(PropertiesFileReader.getData("zipcode"));
		creditCardNumber.sendKeys(PropertiesFileReader.getData("CreditCardNumber"));
		creditMonth.sendKeys(PropertiesFileReader.getData("CreditMonth"));
		creditYear.sendKeys(PropertiesFileReader.getData("CreditYear"));
		nameOnCard.sendKeys(PropertiesFileReader.getData("NameOnCard"));	
	}
	
	public void clickPurchaseFlightButton()
	{
		btnPurchaseFlight.click();
	}
	
	// Initializing the Page Objects:
				public FlightDetails() {
					PageFactory.initElements(driver, this);
				}
	
	
	
	
	
}
