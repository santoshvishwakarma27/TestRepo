package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import baseModule.TestBase;

public class HomePage extends TestBase{
	
	@FindBy(how=How.NAME,using="fromPort")
	WebElement listDepartCity;
	
	
	
	// Initializing the Page Objects:
		public HomePage() {
			PageFactory.initElements(driver, this);
		}
	
	
	
	@FindBy(how=How.NAME,using="toPort")
	WebElement listToCity;
	
	@FindBy(how=How.XPATH,using="//input[@value='Find Flights']")
	WebElement btnFindFlights;
	
	
	
	
	
	public void clickFindFlights()
	{
		btnFindFlights.click();
	}
	
	
	
	public void enterDepartCity(String cityName)
	{
		Select departCity=new Select(listDepartCity);
		departCity.selectByVisibleText(cityName);			
	}

	public void enterToCity(String cityName)
	{
		Select departCity=new Select(listToCity);
		departCity.selectByVisibleText(cityName);			
	}

	}

