package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import baseModule.TestBase;

public class BookingConfirmation extends TestBase{
	
	
	@FindBy(how=How.XPATH,using="/html/body/div[2]/div/h1")
	WebElement successfulMessage;
	
	@FindBy(how=How.XPATH,using="//td[contains(text(),'Id')]/following-sibling::td")
	WebElement bookingId;
	
	public String getSuccessfullMessage()
	{
		String msg=successfulMessage.getText();
		return msg;
	}
	
	public String getBookingId()
	{
		String msg=bookingId.getText();
		return msg;
		
	}
	
	
	// Initializing the Page Objects:
	public BookingConfirmation() {
		PageFactory.initElements(driver, this);
	}
	

}
