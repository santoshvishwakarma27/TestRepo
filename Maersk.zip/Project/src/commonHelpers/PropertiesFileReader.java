package commonHelpers;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesFileReader {
	
	public static String getData(String key) throws IOException
	{
		String fileName=System.getProperty("user.dir")+"\\src\\testData\\UserDetails.properties";	
		FileInputStream fis=new FileInputStream(fileName);
	    Properties p=new Properties();  
		p.load(fis);  		      
		String keyValue=p.getProperty(key);
		return keyValue;  
	}

}
