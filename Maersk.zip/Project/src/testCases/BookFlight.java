package testCases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.*;

import baseModule.TestBase;
import pageObjects.BookingConfirmation;
import pageObjects.ChooseFlight;
import pageObjects.FlightDetails;
import pageObjects.HomePage;

public class BookFlight extends TestBase
{
	
	ChooseFlight chooseFlight;
	HomePage homePage;
	FlightDetails flightDetails;
	BookingConfirmation bookConfirmation;
  
	@BeforeClass
	public void setUp()
	{
		homePage=new HomePage();
		chooseFlight=new ChooseFlight();
		flightDetails=new FlightDetails();
		bookConfirmation=new BookingConfirmation();
		
	}
	
	@Test
	  public void bookFlights() throws IOException 
	  {
		  homePage.enterDepartCity("Boston");	 
		  homePage.enterToCity("London");
		  homePage.clickFindFlights();
		  chooseFlight.clickbtnchooseFlights();
		  flightDetails.enterUserDetails();
		  flightDetails.clickPurchaseFlightButton();	  
		  Assert.assertEquals(bookConfirmation.getSuccessfullMessage(), "Thank you for your purchase today!");
		  System.out.println("Successful Message displayed is:"+ bookConfirmation.getSuccessfullMessage());
		  System.out.println("Booking confirmation ID:"+bookConfirmation.getBookingId());
	  }
}
