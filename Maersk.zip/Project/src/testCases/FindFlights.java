package testCases;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.annotations.Test;

import baseModule.TestBase;
import pageObjects.ChooseFlight;
import pageObjects.HomePage;

@Test
public class FindFlights extends TestBase
{
	HomePage homePage;
	ChooseFlight chooseFlight;
	
	@BeforeClass
	public void setUp()
	{
		homePage=new HomePage();
		chooseFlight=new ChooseFlight();
		
	}
	
  @Test
  public void findFlights() 
  {
	  homePage.enterDepartCity("Boston");	 
	  homePage.enterToCity("London");
	  homePage.clickFindFlights();
	  
	  //Verify choose flight button is displayed or not
	  Assert.assertTrue(chooseFlight.btnChooseFlights.isDisplayed());
	  
	  
  }
  
  
}
