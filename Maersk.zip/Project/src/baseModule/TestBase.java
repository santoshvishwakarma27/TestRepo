package baseModule;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class TestBase {

	public static WebDriver driver;
		 
		 
		 @Parameters ("browser")
		 @BeforeClass
		 public void launchApplication(String browserName) 
		 {
			 
			 
			 switch(browserName)
			 {
			 case "Chrome":				 
					 System.setProperty("webdriver.chrome.driver", "D:\\Setup files\\chromedriver_win3283version\\chromedriver85.exe");
					 driver=new ChromeDriver();
					 driver.manage().window().maximize();
					 driver.get("http://blazedemo.com/");			 			 
			}		

	      }
		 
		 @AfterMethod
		 public void quitBrowser() 
		 {
			 TestBase.driver.quit();
			 
		 }

}