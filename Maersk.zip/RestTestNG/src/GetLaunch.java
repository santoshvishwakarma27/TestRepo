import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetLaunch {
	
	
  @Test
  public void getUserList() 
  {
	  RestAssured.baseURI="https://api.spacexdata.com/v4";
	  RequestSpecification httpRequest=RestAssured.given();
	  Response response=httpRequest.request(Method.GET,"/launches/latest");
	  
	  String responseBody=response.getBody().asString();
	  System.out.println(responseBody);
	  
	  System.out.println(responseBody.contains("flight"));
	  
	  
	  int statusCode=response.getStatusCode();
	  System.out.println("status code in response :"+statusCode);
	  
	  String statusLine=response.getStatusLine();
	  System.out.println("status code in response :"+statusLine);
  }
}